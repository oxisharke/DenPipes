package buildcraft.transport;

public class TileDummyGenericPipe extends TileGenericPipe {

}
