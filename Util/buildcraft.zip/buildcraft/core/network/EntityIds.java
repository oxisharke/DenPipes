package buildcraft.core.network;

public class EntityIds {

	public static final int ROBOT = 10;
	public static final int ENERGY_LASER = 20;
	public static final int LASER = 30;
	public static final int MECHANICAL_ARM = 40;
	public static final int BLOCK = 50;
}
