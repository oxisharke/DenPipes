package buildcraft.core.utils;

public class StringUtil {

	public static String localize(String key) {
		return Localization.get(key);
	}
}
